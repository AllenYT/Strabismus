import pickle  
import os
import sys
import copy
import time
import torch
import torch.nn as nn
import argparse
import importlib
import numpy as np
from datetime import datetime
from models.geomm_net import geomm_net_MT,geomm_net_tmi2024_MT2,XS_MultiNet
from models.mmm_net import mmm_net,mmm_net_seg_align, mmm_net_seg_align_FF,mmm_net_seg_baseline
from models.multimodal import MLP,classifier
from models import save_model, load_single_stream_model,load_single_stream_model_oct,load_single_stream_model_cfpmt,load_single_stream_model_cfpmt_oct,load_single_stream_model_cfpmt_oct_1
from data.DataLoaders import MultiDataLoader, XSDataLoader,FundusDataLoader, OctDataLoader, FundusMTDataLoader, CfpMTOctSingleDataLoader
from utils import *
import random
from data.dataset_refuge import *
from metrics import multilabel_confusion_matrix, accuracy_score, sen_score, spe_score, f1_score
from metrics import confusion_matrix as cfm
from sklearn.metrics import roc_curve, auc, average_precision_score
from sklearn.model_selection import KFold

label2disease_task1 = ['no', 'wxs', 'nxs']
label2disease_task2 = ['ncz', 'cz']
opts = ''

class FocalLoss(nn.Module):
    def __init__(self, alpha=None, gamma=2, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs, targets):
        targets = targets.long()  # Ensure targets are of long type for indexing
        # Compute log_softmax over the inputs
        log_ps = F.log_softmax(inputs, dim=-1)
        # Ensure targets are not one-hot encoded and have shape [batch_size]
        if targets.dim() > 1:
            targets = targets.argmax(dim=1)  # Convert one-hot encoded targets to class indices
        
        # Gather the log probabilities of the true classes
        log_ps = log_ps.gather(1, targets.view(-1, 1)).squeeze()
        # Calculate the probability p_t
        p_t = log_ps.exp()
        # Compute the modulation factor (1 - p_t)^gamma
        modulation = (1 - p_t) ** self.gamma
        # Apply alpha weighting if provided
        if self.alpha is not None:
            alpha = self.alpha.gather(0, targets)  # Gather alpha values for each target class
            loss = -alpha * modulation * log_ps
        else:
            loss = -modulation * log_ps
        # Apply reduction method
        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:
            return loss

def log_to_file(message):
    with open(opts.log_file, "a") as f:
        f.write(message + "\n")

# 计算Kappa系数的函数
def weighted_kappa(confusion_matrix, weights='quadratic'):
    """
    计算加权 Cohen's Kappa
    :param confusion_matrix: 混淆矩阵 (numpy array)
    :param weights: 权重类型 ('linear' or 'quadratic')
    :return: 加权 Kappa 值
    """
    num_classes = confusion_matrix.shape[0]
    total = np.sum(confusion_matrix)

    # 计算权重矩阵
    W = np.zeros((num_classes, num_classes))
    for i in range(num_classes):
        for j in range(num_classes):
            if weights == 'linear':
                W[i, j] = abs(i - j) / (num_classes - 1)
            elif weights == 'quadratic':
                W[i, j] = (i - j) ** 2 / (num_classes - 1) ** 2

    # 观察到的矩阵 O
    O = confusion_matrix / total

    # 期望的一致性矩阵 E
    row_sums = np.sum(confusion_matrix, axis=1) / total  # 每行真实的分布
    col_sums = np.sum(confusion_matrix, axis=0) / total  # 每列预测的分布
    E = np.outer(row_sums, col_sums)  # 外积计算期望矩阵

    # 计算加权 Kappa
    weighted_observed = np.sum(W * O)
    weighted_expected = np.sum(W * E)

    kappa = 1 - (weighted_observed / weighted_expected)
    return kappa

def calculate_metric_percase(pred, gt,dice_scores):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    if pred.sum() > 0 and gt.sum()>0:
        dice = metric.binary.dc(pred, gt)
        dice_scores.append(dice)
        return dice
    elif pred.sum() > 0 and gt.sum()==0:
        dice_scores.append(1)
        return 1
    else:
        dice_scores.append(0)
        return 0

def generate_confusion_matrix(expects, predicts,task_num):
    # 将 one-hot 转换为类别索引
    true_classes = np.argmax(expects, axis=1)
    pred_classes = np.argmax(predicts, axis=1)
    
    # 类别数量
    num_classes = task_num
    
    # 初始化混淆矩阵
    confusion_matrix = np.zeros((num_classes, num_classes), dtype=int)
    
    # 填充混淆矩阵
    for true, pred in zip(true_classes, pred_classes):
        confusion_matrix[true, pred] += 1
    
    return confusion_matrix


def predict_dataloader_2(model, loader, device, net_name="mm-model", if_test=False):
    """支持双分类任务的预测函数，返回 one-hot 格式预测结果"""
    # 初始化双任务存储容器
    task1_predicts, task2_predicts = [], []  # 眼部级别预测（one-hot）
    task1_scores, task2_scores = [], []      # 预测概率（原始概率）
    task1_expects, task2_expects = [], []    # 真实标签（one-hot）
    
    # 细粒度预测（图像级别）
    task1_fine_preds, task2_fine_preds = [], []  # 图像级别预测（one-hot）
    task1_fine_scores, task2_fine_scores = [], [] # 图像级别概率
    task1_fine_expects, task2_fine_expects = [], [] # 真实标签（one-hot）
    
    # 眼部级别缓存
    eye_level_task1 = defaultdict(list)
    eye_level_task2 = defaultdict(list)
    eye_level_expect = defaultdict(list)

    for i, data in enumerate(loader):
        with torch.no_grad():
            # 假设数据格式为 (images, label0_onehot, label1_onehot, ...)
            inputs_cfp, label0_onehot, label1_onehot, imagenames = data
            
            # 前向传播获取双任务输出
            task1_output, task2_output = model(inputs_cfp.to(device))
            
            # 任务1处理（3分类）
            task1_prob = torch.softmax(task1_output, dim=1)
            task1_pred = torch.argmax(task1_prob, dim=1)
            task1_onehot = F.one_hot(task1_pred, num_classes=3)  # 转换为 one-hot
            
            # 任务2处理（2分类）
            task2_prob = torch.softmax(task2_output, dim=1)
            task2_pred = torch.argmax(task2_prob, dim=1)
            task2_onehot = F.one_hot(task2_pred, num_classes=2)  # 转换为 one-hot
            
            # 提取眼部ID（根据文件名约定）
            eye_id = '-'.join(imagenames[0].split('-')[0:2])
            
            # 缓存眼部级别数据（概率）
            eye_level_task1[eye_id].extend(task1_prob.cpu().numpy().tolist())
            eye_level_task2[eye_id].extend(task2_prob.cpu().numpy().tolist())
            if eye_id not in eye_level_expect:
                eye_level_expect[eye_id] = (
                    label0_onehot.cpu().numpy(), 
                    label1_onehot.cpu().numpy()
                )

        # 记录细粒度结果（图像级别）
        task1_fine_preds.extend(task1_onehot.cpu().numpy().tolist())
        task1_fine_scores.extend(task1_prob.cpu().numpy().tolist())
        task1_fine_expects.extend(label0_onehot.cpu().numpy().tolist())
        
        task2_fine_preds.extend(task2_onehot.cpu().numpy().tolist())
        task2_fine_scores.extend(task2_prob.cpu().numpy().tolist())
        task2_fine_expects.extend(label1_onehot.cpu().numpy().tolist())

    # 眼部级别结果聚合
    for eye_id in eye_level_task1:
        # 任务1聚合（3分类）
        task1_probs = np.array(eye_level_task1[eye_id])
        task1_score = np.mean(task1_probs, axis=0)  # 概率平均
        task1_pred = np.argmax(task1_score)
        task1_onehot = np.eye(3)[task1_pred]  # 转为 one-hot
        
        # 任务2聚合（2分类）
        task2_probs = np.array(eye_level_task2[eye_id])
        task2_score = np.mean(task2_probs, axis=0)
        task2_pred = np.argmax(task2_score)
        task2_onehot = np.eye(2)[task2_pred]  # 转为 one-hot
        
        # 存储结果
        task1_predicts.append(task1_onehot.tolist())
        task1_scores.append(task1_score.tolist())
        task2_predicts.append(task2_onehot.tolist())
        task2_scores.append(task2_score.tolist())
        
        # 存储真实标签（已经是 one-hot）
        task1_expects.extend(eye_level_expect[eye_id][0].tolist())
        task2_expects.extend(eye_level_expect[eye_id][1].tolist())

    # 返回结构化结果
    return (
        (task1_predicts, task2_predicts),          # 眼部级别预测（one-hot）
        (task1_scores, task2_scores),              # 眼部级别概率
        (task1_expects, task2_expects),            # 眼部级别真实标签（one-hot）
        (task1_fine_preds, task2_fine_preds),      # 图像级别预测（one-hot）
        (task1_fine_scores, task2_fine_scores),    # 图像级别概率
        (task1_fine_expects, task2_fine_expects)   # 图像级别真实标签（one-hot）
    )

def validate(model, val_loader, device, net_name="mm-model", verbose=True):
    """修改后的双任务验证函数"""
    if verbose:
        print("-" * 45 + "validation" + "-" * 45)

    # 获取双任务预测结果
    # 假设 predict_dataloader_2 返回格式: 
    (task1_preds, task2_preds), (task1_scores, task2_scores), (task1_labels, task2_labels), eye_level_expect, _1, _2 = predict_dataloader_2(
        model, val_loader, device, net_name, if_test=False
    )
    task1_preds = np.array(task1_preds)
    task2_preds = np.array(task2_preds)
    task1_scores = np.array(task1_scores)
    task2_scores = np.array(task2_scores)
    task1_labels = np.array(task1_labels)
    task2_labels = np.array(task2_labels)
    
    # 初始化结果字典
    results = {
        'task1': {'overall': {}, 'classes': {}},
        'task2': {'overall': {}, 'classes': {}}
    }

    # ==================== 任务1 (3分类) 验证 ====================
    # 生成混淆矩阵
    task1_cm = generate_confusion_matrix(task1_labels, task1_preds,3)
    task1_overall_kappa = weighted_kappa(task1_cm)
    
    # 存储整体指标
    results['task1']['overall']['kappa'] = task1_overall_kappa
    results['task1']['overall']['cm'] = task1_cm

    # 逐类别计算指标
    for i in range(3):  # 固定3分类
        class_name = label2disease_task1[i]  # 假设已定义任务1的标签映射
        confusion_matrix_i = multilabel_confusion_matrix(task1_labels, task1_preds)[i]
        predicts_specific = task1_scores[:, i].tolist()
        expects_specific = task1_labels[:, i].tolist()
        fpr, tpr, th = roc_curve(expects_specific, predicts_specific, pos_label=1)
        auc_specific = auc(fpr, tpr)
        
        # 计算指标
        results['task1']['classes'][class_name] = {
            'spe': spe_score(confusion_matrix_i),
            'sen': sen_score(confusion_matrix_i),
            'acc': accuracy_score(confusion_matrix_i),
            'f1': f1_score(spe_score(confusion_matrix_i), sen_score(confusion_matrix_i)),
            'auc': auc_specific,
            'ap': average_precision_score(expects_specific, predicts_specific),
            'kappa': weighted_kappa(confusion_matrix_i)
        }

    # 计算任务1整体指标
    results['task1']['overall']['sen'] = np.mean([v['sen'] for v in results['task1']['classes'].values()])
    results['task1']['overall']['spe'] = np.mean([v['spe'] for v in results['task1']['classes'].values()])
    results['task1']['overall']['f1'] = np.mean([v['f1'] for v in results['task1']['classes'].values()])
    results['task1']['overall']['auc'] = np.mean([v['auc'] for v in results['task1']['classes'].values()])
    results['task1']['overall']['ap'] = np.mean([v['ap'] for v in results['task1']['classes'].values()])
    results['task1']['overall']['acc'] = np.mean([v['acc'] for v in results['task1']['classes'].values()])

    # ==================== 任务2 (2分类) 验证 ====================
    # 生成二分类混淆矩阵
    task2_cm = generate_confusion_matrix(task2_labels, task2_preds,2)
    task2_overall_kappa = weighted_kappa(task2_cm)
    
    results['task2']['overall']['kappa'] = task2_overall_kappa
    results['task2']['overall']['cm'] = task2_cm

    # 二分类指标计算
    for i in range(2):  # 固定2分类
        class_name = label2disease_task2[i]  # 假设已定义任务1的标签映射
        confusion_matrix_i = multilabel_confusion_matrix(task2_labels, task2_preds)[i]
        predicts_specific = task2_scores[:, i].tolist()
        expects_specific = task2_labels[:, i].tolist()
        fpr, tpr, th = roc_curve(expects_specific, predicts_specific, pos_label=1)
        auc_specific = auc(fpr, tpr)
        
        # 计算指标
        results['task2']['classes'][class_name] = {
            'spe': spe_score(confusion_matrix_i),
            'sen': sen_score(confusion_matrix_i),
            'acc': accuracy_score(confusion_matrix_i),
            'f1': f1_score(spe_score(confusion_matrix_i), sen_score(confusion_matrix_i)),
            'auc': auc_specific,
            'ap': average_precision_score(expects_specific, predicts_specific),
            'kappa': weighted_kappa(confusion_matrix_i)
        }

    # 任务2整体指标
    results['task2']['overall']['sen'] = np.mean([v['sen'] for v in results['task2']['classes'].values()])
    results['task2']['overall']['spe'] = np.mean([v['spe'] for v in results['task2']['classes'].values()])
    results['task2']['overall']['f1'] = np.mean([v['f1'] for v in results['task2']['classes'].values()])
    results['task2']['overall']['auc'] = np.mean([v['auc'] for v in results['task2']['classes'].values()])
    results['task2']['overall']['ap'] = np.mean([v['ap'] for v in results['task2']['classes'].values()])
    results['task2']['overall']['acc'] = np.mean([v['acc'] for v in results['task2']['classes'].values()])

    # ==================== 打印结果 ====================
    def print_results(task_name, task_data):
        
        print(f"\n{task_name} Results:")
        print("Confusion Matrix:")
        print(task_data['overall']['cm'])
        print("cls\tsen\tspe\tf1\tauc\tap\tacc\tkappa")
        for cls in task_data['classes']:
            print(f"{cls}\t"
                  f"{task_data['classes'][cls]['sen']:.4f}\t"
                  f"{task_data['classes'][cls]['spe']:.4f}\t"
                  f"{task_data['classes'][cls]['f1']:.4f}\t"
                  f"{task_data['classes'][cls]['auc']:.4f}\t"
                  f"{task_data['classes'][cls]['ap']:.4f}\t"
                  f"{task_data['classes'][cls]['acc']:.4f}\t"
                  f"{task_data['classes'][cls]['kappa']:.4f}")
        print(f"Overall: Kappa={task_data['overall']['kappa']:.4f}, "
              f"AUC={task_data['overall']['auc']:.4f}, "
              f"Acc={task_data['overall']['acc']:.4f}")
        
        log_to_file(f"\n{task_name} Results:")
        log_to_file("Confusion Matrix:")
        log_to_file(str(task_data['overall']['cm']))
        log_to_file("cls\tsen\tspe\tf1\tauc\tap\tacc\tkappa")
        for cls in task_data['classes']:
            log_to_file(f"{cls}\t"
                         f"{task_data['classes'][cls]['sen']:.4f}\t"
                         f"{task_data['classes'][cls]['spe']:.4f}\t"
                         f"{task_data['classes'][cls]['f1']:.4f}\t"
                         f"{task_data['classes'][cls]['auc']:.4f}\t"
                         f"{task_data['classes'][cls]['ap']:.4f}\t"
                         f"{task_data['classes'][cls]['acc']:.4f}\t"
                         f"{task_data['classes'][cls]['kappa']:.4f}")
        log_to_file(f"Overall: Kappa={task_data['overall']['kappa']:.4f}, "
                    f"AUC={task_data['overall']['auc']:.4f}, "
                    f"Acc={task_data['overall']['acc']:.4f}")
            

    if verbose:
        print_results("3-Class Task", results['task1'])
        print_results("2-Class Task", results['task2'])
        print("-" * 90)

    # 返回关键指标（根据主函数需求调整）
    return (results['task1']['overall']['acc'], 
            results['task2']['overall']['acc'])

def parse_args():
    parser = argparse.ArgumentParser(description="training")
    parser.add_argument("--train_collection", type=str,
                        default='image_data/topcon-mm/train',
                        help="train collection path")
    parser.add_argument("--val_collection", type=str,
                        default='image_data/topcon-mm/val',
                        help="val collection path")
    parser.add_argument("--test_collection", type=str,
                        default='image_data/topcon-mm/test',
                        help="test collection path")
    parser.add_argument("--print_freq", default=20, type=int, help="print frequent (default: 20)")
    parser.add_argument("--model_configs", type=str, default='config_fundus.py',
                        help="filename of the model configuration file.")
    parser.add_argument("--run_id", default=4, type=int, help="run_id (default: 0)")
    parser.add_argument("--device", default="cuda:1", type=str, help="cuda:n or cpu (default: 0)")
    parser.add_argument("--num_workers", default=4, type=int, help="number of threads for sampling. (default: 0)")
    parser.add_argument("--checkpoint", default=None, type=str, help="checkpoint path")
    parser.add_argument("--seed", default=100, type=int)
    parser.add_argument("--batch_size", default=8, type=int)
    parser.add_argument("--overwrite", default=True, type=bool)
    parser.add_argument("--log_file", default=None, type=str,help="log_file path")
    args = parser.parse_args()
    return args


class DynamicWeightedLoss(nn.Module):
    def __init__(self, num_tasks=2):
        super().__init__()
        self.log_vars = nn.Parameter(torch.zeros(num_tasks))  # 可学习的损失权重

    def forward(self, *losses):
        total_loss = 0
        for i, loss in enumerate(losses):
            total_loss += torch.exp(-self.log_vars[i]) * loss + self.log_vars[i]
        return total_loss

# def adjust_learning_rate(optimizer, optim_params):
#     optim_params['lr'] *= 0.5
#     print('learning rate:', optim_params['lr'])
#     for param_group in optimizer.param_groups:
#         param_group['lr'] = optim_params['lr']
#     if optim_params['lr'] < optim_params['lr_min']:
#         return True
#     else:
#         return False

def adjust_learning_rate(optimizer, optim_params, epoch):
    # 只有在达到衰减的epoch时才进行衰减
    if epoch >= optim_params['lr_decay_start'] and (epoch - optim_params['lr_decay_start']) % optim_params['lr_decay_step'] == 0:
        optim_params['lr'] *= optim_params['lr_decay']  # 衰减学习率
        print('Learning rate adjusted:', optim_params['lr'])

        # 更新优化器的学习率
        for param_group in optimizer.param_groups:
            param_group['lr'] = optim_params['lr']

    # 如果学习率已经小于最小学习率，则返回True，否则返回False
    if optim_params['lr'] < optim_params['lr_min']:
        return True
    else:
        return False

def model_structure(net_name):
    return mmm_net

def select_dataloader(modality):
    print("initialize dataloader for {}".format(modality))

    return XSDataLoader 

# def main(opts):
#     # 初始化日志
#     configs = load_config(opts.model_configs)
#     if opts.log_file is None:
#         from datetime import datetime
#         date_str = datetime.now().strftime("%Y-%m-%d")
#         opts.log_file = f"/disk/user/yt/FOMM/log/{configs.modality}/{date_str}_runid_{opts.run_id}.txt"
    
#     if os.path.exists(opts.log_file):
#         os.remove(opts.log_file)

#     # 设备配置
#     device = torch.device("cuda" if (torch.cuda.is_available() and opts.device != "cpu") else "cpu")
#     log_to_file(f"Device: {device}")
    
#     # 检查保存路径
#     if not runid_checker(opts, configs.if_syn):
#         return
    
#     # 五折交叉验证循环
#     # 初始化数据集
#     splitprint()
#     data_initializer = select_dataloader(configs.modality)(opts, configs)
    
#     train_loader, val_loader, test_loader = data_initializer.get_training_dataloader()

#     # 初始化模型
#     splitprint()
#     model = XS_MultiNet().to(device)
    
#     # 定义损失函数
#     criterion1 = FocalLoss(gamma=2, reduction='mean')  # 3分类任务
#     criterion2 = FocalLoss(gamma=2, reduction='mean')  # 2分类任务
#     # multi_loss = DynamicWeightedLoss(num_tasks=2)  # 双任务权重调整

#     # 优化器配置
#     if configs.train_params["optimizer"] == "adam":
#         optimizer_params = configs.train_params["adam"]
#         optimizer = torch.optim.Adam(
#             # list(model.parameters()) + list(multi_loss.parameters()),
#             model.parameters(),
#             lr=optimizer_params["lr"],
#             weight_decay=optimizer_params["weight_decay"]
#         )

#     if configs.train_params["optimizer"] == "sgd":
#         optimizer_params = configs.train_params["sgd"]
#         optimizer = torch.optim.SGD(model.parameters(), lr=optimizer_params["lr"],
#                                     momentum=optimizer_params["momentum"],
#                                     weight_decay=optimizer_params["weight_decay"])

#     # 训练状态跟踪
#     tolerance = 0
#     best_metric = 0
#     best_acc1 = 0  # 3分类最佳准确率
#     best_acc2 = 0  # 2分类最佳准确率
#     best_model_wts = None

#     # 训练循环
#     for epoch in range(configs.train_params["max_epoch"]):
#         print(f'\nEpoch {epoch+1}/{configs.train_params["max_epoch"]}')
#         log_to_file(f"Epoch {epoch+1}/{configs.train_params['max_epoch']}")

#         # 训练阶段
#         model.train()
#         batch_time = AverageMeter()
#         data_time = AverageMeter()
#         losses = AverageMeter()
#         losses1 = AverageMeter()  # 任务1损失
#         losses2 = AverageMeter()  # 任务2损失

#         end = time.time()
#         for i, (images, label0, label1,name) in enumerate(train_loader):
#             # 数据加载
#             data_time.update(time.time() - end)
#             images = images.to(device)
#             label0 = label0.to(device)
#             label1 = label1.to(device)

#             # 前向传播
#             optimizer.zero_grad()
#             output1, output2 = model(images)
            
#             # 损失计算
#             loss1 = criterion1(output1, label0)
#             loss2 = criterion2(output2, label1)
#             # total_loss = multi_loss(loss1, loss2)
#             total_loss = 0.5*loss1 + 0.5*loss2
            
#             # 反向传播
#             total_loss.backward()
#             optimizer.step()

#             # 统计记录
#             batch_size = images.size(0)
#             losses.update(total_loss.item(), batch_size)
#             losses1.update(loss1.item(), batch_size)
#             losses2.update(loss2.item(), batch_size)
            
#             batch_time.update(time.time() - end)
#             end = time.time()

#             # 日志打印
#             if i % opts.print_freq == 0:
#                 log_msg = (
#                     f'Epoch: [{epoch}][{i}/{len(train_loader)}]\t'
#                     f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
#                     f'Loss {losses.val:.4f} ({losses.avg:.4f})\t'
#                     f'Loss1(3cls) {losses1.val:.4f} ({losses1.avg:.4f})\t'
#                     f'Loss2(2cls) {losses2.val:.4f} ({losses2.avg:.4f})'
#                 )
#                 print(log_msg)
#                 log_to_file(log_msg)

#         # 验证阶段
#         model.eval()
#         acc1,acc2 = validate(model, val_loader, device)
        
#         # 更新最佳模型
#         current_acc1 = acc1
#         current_acc2 = acc2
#         current_avg = (current_acc1 + current_acc2) / 2

#         if current_avg > best_metric:
#             best_metric = current_avg
#             best_acc1 = current_acc1
#             best_acc2 = current_acc2
#             best_model_wts = copy.deepcopy(model.state_dict())
#             save_model(best_model_wts, opts, epoch, best_metric, 
#                       save_filename="best_avg_model.pth", if_syn=configs.if_syn)
#             tolerance = 0
            
#         # 独立保存最佳单任务模型
#         if current_acc1 > best_acc1:
#             best_acc1 = current_acc1
#             save_model(model.state_dict(), opts, epoch, best_acc1,
#                       save_filename="best_3cls_model.pth", if_syn=configs.if_syn)
#             tolerance = 0
            
#         if current_acc2 > best_acc2:
#             best_acc2 = current_acc2
#             save_model(model.state_dict(), opts, epoch, best_acc2,
#                       save_filename="best_2cls_model.pth", if_syn=configs.if_syn)
#             tolerance = 0

#         # 日志记录
#         log_msg = (
#             f"Current Accuracies:\n"
#             f"3-Class: {current_acc1:.4f} (Best: {best_acc1:.4f})\n"
#             f"2-Class: {current_acc2:.4f} (Best: {best_acc2:.4f})\n"
#             f"Average: {current_avg:.4f} (Best: {best_metric:.4f})"
#         )
#         print(log_msg)
#         log_to_file(log_msg)

#         # 学习率调整
#         if epoch > optimizer_params["lr_decay_start"]:
#             if_stop = adjust_learning_rate(optimizer, optimizer_params, epoch)
#             if if_stop:
#                 print("Early stopping based on learning rate schedule.")
#                 break
#             print(f"Best Acc: {best_metric:.4f}")

#     # 最终保存
#     save_model(model.state_dict(), opts, epoch, best_metric,
#               save_filename="final_model.pth", if_syn=configs.if_syn)
   
# def main(opts):
#     # 初始化日志
#     configs = load_config(opts.model_configs)

#     fold_losses = {
#         'train': [],
#         'val_3cls_acc': [],
#         'val_2cls_acc': []
#     }
    
#     if opts.log_file is None:
#         date_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
#         opts.log_file = f"/disk/user/yt/FOMM/log/{configs.modality}/{date_str}_runid_{opts.run_id}.txt"
    
#     if os.path.exists(opts.log_file):
#         os.remove(opts.log_file)

#     # 设备配置
#     device = torch.device("cuda" if (torch.cuda.is_available() and opts.device != "cpu") else "cpu")
#     log_to_file(f"Device: {device}")

    
#     # 五折交叉验证循环
#     # 初始化数据集
#     splitprint()

    
#     for fold in range(10):  # 修改为10折循环
#         print(f'\n{"="*30} Fold {fold} {"="*30}')
#         log_to_file(f"\n===== Fold {fold} =====")
        
#         opts.train_collection = f'/disk/user/yt/nine_position/data_split/fold{fold}/train'
#         opts.val_collection = f'/disk/user/yt/nine_position/data_split/fold{fold}/val'
#         opts.test_collection = f'/disk/user/yt/nine_position/data_split/fold{fold}/val'
#         opts.run_id = fold  # 自动设置run_id
            
#         # 检查保存路径
#         if not runid_checker(opts, configs.if_syn):
#             return
        
#         # 初始化数据集
#         data_initializer = select_dataloader(configs.modality)(opts, configs)
#         train_loader, val_loader, _ = data_initializer.get_training_dataloader()
        
#         # 初始化模型
#         model = XS_MultiNet().to(device)
        
#         # 定义损失函数
#         criterion1 = FocalLoss(gamma=2, reduction='mean')  # 3分类任务
#         criterion2 = FocalLoss(gamma=2, reduction='mean')  # 2分类任务

#         # 优化器配置
#         if configs.train_params["optimizer"] == "adam":
#             optimizer_params = configs.train_params["adam"]
#             optimizer = torch.optim.Adam(
#                 model.parameters(),
#                 lr=optimizer_params["lr"],
#                 weight_decay=optimizer_params["weight_decay"]
#             )

#         if configs.train_params["optimizer"] == "sgd":
#             optimizer_params = configs.train_params["sgd"]
#             optimizer = torch.optim.SGD(model.parameters(), lr=optimizer_params["lr"],
#                                         momentum=optimizer_params["momentum"],
#                                         weight_decay=optimizer_params["weight_decay"])
        
#         # 训练循环
#         fold_train_losses = []  
#         fold_val_acc1 = []      
#         fold_val_acc2 = []     
        
#         # 训练状态跟踪
#         tolerance = 0
#         best_metric = 0
#         best_acc1 = 0  # 3分类最佳准确率
#         best_acc2 = 0  # 2分类最佳准确率
#         best_model_wts = None
        
#         # 训练循环
#         for epoch in range(configs.train_params["max_epoch"]):
#             print(f'\nEpoch {epoch+1}/{configs.train_params["max_epoch"]}')
#             log_to_file(f"Epoch {epoch+1}/{configs.train_params['max_epoch']}")

#             # 训练阶段
#             model.train()
#             batch_time = AverageMeter()
#             data_time = AverageMeter()
#             losses = AverageMeter()
#             losses1 = AverageMeter()  # 任务1损失
#             losses2 = AverageMeter()  # 任务2损失

#             end = time.time()
#             for i, (images, label0, label1,name) in enumerate(train_loader):
#                 # 数据加载
#                 data_time.update(time.time() - end)
#                 images = images.to(device)
#                 label0 = label0.to(device)
#                 label1 = label1.to(device)

#                 # 前向传播
#                 optimizer.zero_grad()
#                 output1, output2 = model(images)
                
#                 # 损失计算
#                 loss1 = criterion1(output1, label0)
#                 loss2 = criterion2(output2, label1)
#                 total_loss = 0.5*loss1 + 0.5*loss2
                
#                 # 反向传播
#                 total_loss.backward()
#                 optimizer.step()

#                 # 统计记录
#                 batch_size = images.size(0)
#                 losses.update(total_loss.item(), batch_size)
#                 losses1.update(loss1.item(), batch_size)
#                 losses2.update(loss2.item(), batch_size)
                
#                 batch_time.update(time.time() - end)
#                 end = time.time()

#                 # 日志打印
#                 if i % opts.print_freq == 0:
#                     log_msg = (
#                         f'Epoch: [{epoch}][{i}/{len(train_loader)}]\t'
#                         f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
#                         f'Loss {losses.val:.4f} ({losses.avg:.4f})\t'
#                         f'Loss1(3cls) {losses1.val:.4f} ({losses1.avg:.4f})\t'
#                         f'Loss2(2cls) {losses2.val:.4f} ({losses2.avg:.4f})'
#                     )
#                     print(log_msg)
#                     log_to_file(log_msg)

#             # 验证阶段
#             model.eval()
#             acc1,acc2 = validate(model, val_loader, device)
            
#             # 更新最佳模型
#             current_acc1 = acc1
#             current_acc2 = acc2
#             current_avg = (current_acc1 + current_acc2) / 2

#             if current_avg > best_metric:
#                 best_metric = current_avg
#                 best_acc1 = current_acc1
#                 best_acc2 = current_acc2
#                 best_model_wts = copy.deepcopy(model.state_dict())
#                 save_model(best_model_wts, opts, epoch, best_metric, 
#                         save_filename="best_avg_model.pth", if_syn=configs.if_syn)
                
#             # 独立保存最佳单任务模型
#             if current_acc1 > best_acc1:
#                 best_acc1 = current_acc1
#                 save_model(model.state_dict(), opts, epoch, best_acc1,
#                         save_filename="best_3cls_model.pth", if_syn=configs.if_syn)
                
#             if current_acc2 > best_acc2:
#                 best_acc2 = current_acc2
#                 save_model(model.state_dict(), opts, epoch, best_acc2,
#                         save_filename="best_2cls_model.pth", if_syn=configs.if_syn)

#             # 日志记录
#             log_msg = (
#                 f"Current Accuracies:\n"
#                 f"3-Class: {current_acc1:.4f} (Best: {best_acc1:.4f})\n"
#                 f"2-Class: {current_acc2:.4f} (Best: {best_acc2:.4f})\n"
#                 f"Average: {current_avg:.4f} (Best: {best_metric:.4f})"
#             )
#             print(log_msg)
#             log_to_file(log_msg)

#             # 学习率调整
#             if epoch > optimizer_params["lr_decay_start"]:
#                 if_stop = adjust_learning_rate(optimizer, optimizer_params, epoch)
#                 # if if_stop:
#                 #     print("Early stopping based on learning rate schedule.")
#                 #     break
#                 print(f"Best Acc: {best_metric:.4f}")
            
#             fold_train_losses.append(losses.avg)
#             fold_val_acc1.append(current_acc1)
#             fold_val_acc2.append(current_acc2)
        
#         # ⭐保存当前fold的损失数据
#         fold_losses['train'].append(fold_train_losses)
#         fold_losses['val_3cls_acc'].append(fold_val_acc1)
#         fold_losses['val_2cls_acc'].append(fold_val_acc2)
    
#     # 最终保存
#     save_model(model.state_dict(), opts, epoch, best_metric,
#               save_filename="final_model.pth", if_syn=configs.if_syn)
    
#     save_path = f"/disk/user/yt/FOMM/loss_records/{datetime.now().strftime('%Y%m%d')}_10fold_losses.pkl"
#     with open(save_path, 'wb') as f:
#         pickle.dump(fold_losses, f)
#     print(f"Loss records saved to {save_path}")
#     return save_path

def main(opts):
    # 初始化日志
    configs = load_config(opts.model_configs)

    fold_losses = {
        'train': [],
        'val_3cls_acc': [],
        'val_2cls_acc': []
    }
    
    if opts.log_file is None:
        date_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        opts.log_file = f"/disk/user/yt/FOMM/log/{configs.modality}/{date_str}_runid_{opts.run_id}.txt"
    
    if os.path.exists(opts.log_file):
        os.remove(opts.log_file)

    # 设备配置
    device = torch.device("cuda" if (torch.cuda.is_available() and opts.device != "cpu") else "cpu")
    log_to_file(f"Device: {device}")
    
    # 五折交叉验证循环
    # 初始化数据集
    splitprint()
    
    fold = opts.run_id
    print(f'\n{"="*30} Fold {fold} {"="*30}')
    log_to_file(f"\n===== Fold {fold} =====")
    
    # opts.train_collection = f'/disk/user/yt/nine_position/data_split/fold{fold}/train'
    # opts.val_collection = f'/disk/user/yt/nine_position/data_split/fold{fold}/val'
    # opts.test_collection = f'/disk/user/yt/nine_position/data_split/fold{fold}/val'
    # opts.run_id = fold  # 自动设置run_id
        
    # 检查保存路径
    if not runid_checker(opts, configs.if_syn):
        return
    
    # 初始化数据集
    data_initializer = select_dataloader(configs.modality)(opts, configs)
    train_loader, val_loader, _ = data_initializer.get_training_dataloader()
    
    # 初始化模型
    model = XS_MultiNet().to(device)
    
    # 定义损失函数
    criterion1 = FocalLoss(gamma=2, reduction='mean')  # 3分类任务
    criterion2 = FocalLoss(gamma=2, reduction='mean')  # 2分类任务
    
    # 优化器配置
    if configs.train_params["optimizer"] == "adam":
        optimizer_params = configs.train_params["adam"]
        optimizer = torch.optim.Adam(
            model.parameters(),
            lr=optimizer_params["lr"],
            weight_decay=optimizer_params["weight_decay"]
        )
        
    if configs.train_params["optimizer"] == "sgd":
        optimizer_params = configs.train_params["sgd"]
        optimizer = torch.optim.SGD(model.parameters(), lr=optimizer_params["lr"],
                                    momentum=optimizer_params["momentum"],
                                    weight_decay=optimizer_params["weight_decay"])
    
    # 训练循环
    fold_train_losses = []  
    fold_val_acc1 = []      
    fold_val_acc2 = []     
    
    # 训练状态跟踪
    best_metric = 0
    best_acc1 = 0  # 3分类最佳准确率
    best_acc2 = 0  # 2分类最佳准确率
    best_model_wts = None
    
    # 训练循环
    for epoch in range(configs.train_params["max_epoch"]):
        print(f'\nEpoch {epoch+1}/{configs.train_params["max_epoch"]}')
        log_to_file(f"Epoch {epoch+1}/{configs.train_params['max_epoch']}")
        # 训练阶段
        model.train()
        batch_time = AverageMeter()
        data_time = AverageMeter()
        losses = AverageMeter()
        losses1 = AverageMeter()  # 任务1损失
        losses2 = AverageMeter()  # 任务2损失
        end = time.time()
        for i, (images, label0, label1,name) in enumerate(train_loader):
            # 数据加载
            data_time.update(time.time() - end)
            images = images.to(device)
            label0 = label0.to(device)
            label1 = label1.to(device)
            # 前向传播
            optimizer.zero_grad()
            output1, output2 = model(images)
            
            # 损失计算
            loss1 = criterion1(output1, label0)
            loss2 = criterion2(output2, label1)
            total_loss = 0.5*loss1 + 0.5*loss2
            
            # 反向传播
            total_loss.backward()
            optimizer.step()
            # 统计记录
            batch_size = images.size(0)
            losses.update(total_loss.item(), batch_size)
            losses1.update(loss1.item(), batch_size)
            losses2.update(loss2.item(), batch_size)
            
            batch_time.update(time.time() - end)
            end = time.time()
            # 日志打印
            if i % opts.print_freq == 0:
                log_msg = (
                    f'Epoch: [{epoch}][{i}/{len(train_loader)}]\t'
                    f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                    f'Loss {losses.val:.4f} ({losses.avg:.4f})\t'
                    f'Loss1(3cls) {losses1.val:.4f} ({losses1.avg:.4f})\t'
                    f'Loss2(2cls) {losses2.val:.4f} ({losses2.avg:.4f})'
                )
                print(log_msg)
                log_to_file(log_msg)
        # 验证阶段
        model.eval()
        acc1,acc2 = validate(model, val_loader, device)
        
        # 更新最佳模型
        current_acc1 = acc1
        current_acc2 = acc2
        current_avg = (current_acc1 + current_acc2) / 2
        if current_avg > best_metric:
            best_metric = current_avg
            best_acc1 = current_acc1
            best_acc2 = current_acc2
            best_model_wts = copy.deepcopy(model.state_dict())
            save_model(best_model_wts, opts, epoch, best_metric, 
                    save_filename="best_avg_model.pth", if_syn=configs.if_syn)
            
        # 独立保存最佳单任务模型
        if current_acc1 > best_acc1:
            best_acc1 = current_acc1
            save_model(model.state_dict(), opts, epoch, best_acc1,
                    save_filename="best_3cls_model.pth", if_syn=configs.if_syn)
            
        if current_acc2 > best_acc2:
            best_acc2 = current_acc2
            save_model(model.state_dict(), opts, epoch, best_acc2,
                    save_filename="best_2cls_model.pth", if_syn=configs.if_syn)
            
        # 日志记录
        log_msg = (
            f"Current Accuracies:\n"
            f"3-Class: {current_acc1:.4f} (Best: {best_acc1:.4f})\n"
            f"2-Class: {current_acc2:.4f} (Best: {best_acc2:.4f})\n"
            f"Average: {current_avg:.4f} (Best: {best_metric:.4f})"
        )
        
        print(log_msg)
        log_to_file(log_msg)
        
        # 学习率调整
        if epoch > optimizer_params["lr_decay_start"]:
            if_stop = adjust_learning_rate(optimizer, optimizer_params, epoch)
            # if if_stop:
            #     print("Early stopping based on learning rate schedule.")
            #     break
            print(f"Best Acc: {best_metric:.4f}")
        
        fold_train_losses.append(losses.avg)
        fold_val_acc1.append(current_acc1)
        fold_val_acc2.append(current_acc2)
        save_model(model.state_dict(), opts, epoch, best_acc1,
                    save_filename="epoch"+str(epoch), if_syn=configs.if_syn)
    
    # ⭐保存当前fold的损失数据
    fold_losses['train'].append(fold_train_losses)
    fold_losses['val_3cls_acc'].append(fold_val_acc1)
    fold_losses['val_2cls_acc'].append(fold_val_acc2)
    
    # 最终保存
    save_model(model.state_dict(), opts, epoch, best_metric,
              save_filename="final_model.pth", if_syn=configs.if_syn)
    
    save_path = f"/disk/user/yt/FOMM/loss_records/{datetime.now().strftime('%Y%m%d')}_fold{fold}_losses.pkl"
    
    with open(save_path, 'wb') as f:
        pickle.dump(fold_losses, f)
        
    print(f"Loss records saved to {save_path}")
    # return save_path

def plot_loss_curves(loss_data, save_path):
    """绘制十折训练损失曲线
    Args:
        loss_data (dict): 包含各折训练损失的字典
        save_path (str): 图片保存路径
    """
    plt.figure(figsize=(10, 6))  # 增大画布尺寸
    
    # 创建颜色映射 (10种易区分颜色)
    colors = plt.cm.tab10(np.linspace(0, 1, 10))
    
    # 绘制各折曲线
    for fold_idx, fold_loss in enumerate(loss_data['train']):
        epochs = range(1, len(fold_loss)+1)  # 从1开始的整数epoch
        plt.plot(epochs, 
                 fold_loss,
                 color=colors[fold_idx],
                 linewidth=1.5,
                 alpha=0.7,
                 label=f'Fold {fold_idx+1}')  # Fold编号从1开始

    # 坐标轴设置
    plt.xticks(epochs[::10])  # 强制显示所有整数epoch
    plt.xlabel('Epoch', fontsize=12, labelpad=10)
    plt.ylabel('Loss', fontsize=12, labelpad=10)
    plt.title('10-Fold Cross Validation Training Loss', fontsize=14, pad=20)
    
    # 图例设置
    plt.legend(loc='upper right', 
               ncol=1,  # 分两列显示
               fontsize=8,
               frameon=True)
    
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')  # 提高保存分辨率
    print(f"Loss plot saved to {save_path}")
    plt.close()

def load_and_plot_losses(base_path, save_path):
    """加载10折的损失数据并绘制曲线
    
    Args:
        base_path (str): PKL文件的基础路径（不包含fold数字和扩展名）
        save_path (str): 图片保存路径
    """
    plt.figure(figsize=(10, 7))  # 增大画布尺寸
    
    # 创建颜色映射 (10种易区分颜色)
    colors = plt.cm.tab10(np.linspace(0, 1, 10))
    
    max_epochs = 0  # 记录最大epoch数以统一x轴
    
    # 加载并绘制每一折的数据
    for fold_idx in range(10):
        pkl_path = f"{base_path}_fold{fold_idx}_losses.pkl"
        
        # 检查文件是否存在
        if not os.path.exists(pkl_path):
            print(f"Warning: File not found - {pkl_path}")
            continue
            
        # 加载数据
        with open(pkl_path, 'rb') as f:
            loss_data = pickle.load(f)
        
        # 提取训练损失
        train_loss = loss_data['train']
        train_loss[0].append(train_loss[0][-1])
        epochs = range(0, 201)
        
        # 更新最大epoch数
        max_epochs = 200
        
        # 绘制曲线
        plt.plot(epochs, 
                 train_loss[0],
                 color=colors[fold_idx],
                 linewidth=1.5,
                 alpha=0.7,
                 label=f'Fold {fold_idx+1}')

    # 坐标轴设置
    plt.xticks(epochs[::10])  # 强制显示所有整数epoch
    plt.xlabel('Epoch', fontsize=12, labelpad=10)
    plt.ylabel('Loss', fontsize=12, labelpad=10)
    plt.title('10-Fold Cross Validation Training Loss', fontsize=14, pad=20)
    
    # 图例设置
    plt.legend(loc='upper right', 
               ncol=1,  # 分两列显示
               fontsize=9,
               frameon=True)
    
    # 保存图片
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Loss plot saved to {save_path}")
    plt.close()
    
def inspect_pkl(file_path):
    # 加载数据
    with open(file_path, "rb") as f:
        data = pickle.load(f)
    
    # 打印基本信息
    print("--- Data Type ---")
    print(type(data))  # 查看对象类型（如 dict、list 等）
    
    print("\n--- Data Structure ---")
    if isinstance(data, dict):
        print("Keys:", data.keys())  # 如果是字典，显示所有键
    elif isinstance(data, list):
        print("Length:", len(data))  # 如果是列表，显示长度
    
    print("\n--- Sample Content ---")
    print(len(data['train'][0]))  # 打印前几条数据（如果数据量较大，可能只显示部分）

# 示例调用
if __name__ == "__main__":
    opts = parse_args()
    torch.multiprocessing.set_sharing_strategy('file_system')
    os.environ['CUDA_VISIBLE_DEVICES'] = '3'
    random.seed(opts.seed)
    np.random.seed(opts.seed)
    torch.manual_seed(opts.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(opts.seed)
    main(opts)
    # plot_save_path = f"/disk/user/yt/FOMM/plots/{datetime.now().strftime('%Y%m%d')}_10fold_loss.png"
    # with open(save_path, 'rb') as f:  # 读取之前保存的损失数
    #     loss_data = pickle.load(f)
    # plot_loss_curves(loss_data, plot_save_path)
    # base_pkl_path = "/disk/user/yt/FOMM/loss_records/20250517"
    # plot_save_path = "/disk/user/yt/FOMM/plots/10fold_training_loss.png"
    # load_and_plot_losses(base_pkl_path, plot_save_path)
    # inspect_pkl("/disk/user/yt/FOMM/loss_records/20250517_fold0_losses.pkl")
    


