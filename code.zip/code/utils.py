import os
import copy
import torch
import shutil
import importlib
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from collections import defaultdict

def compute_dice(pred, target, num_classes=3):
    dice_scores = []
    for i in range(num_classes):
        pred_class = pred[:, i, :, :]
        target_class = target[:, i, :, :]
        intersection = torch.sum(pred_class * target_class)
        union = torch.sum(pred_class) + torch.sum(target_class)
        dice_score = 2 * intersection / (union + 1e-6)  # 防止除零错误
        dice_scores.append(dice_score)
    return dice_scores

def compute_iou(pred, target, num_classes=3):
    iou_scores = []
    for i in range(num_classes):
        intersection = torch.sum(pred * target == i)
        union = torch.sum(pred + target == i)
        iou_score = intersection / (union + 1e-6)
        iou_scores.append(iou_score)
    return iou_scores

def compute_hd95(pred, target):
    """
    计算Hausdorff距离的95%分位数
    pred和target应为二进制的分割图像，大小相同
    """
    from scipy.spatial.distance import directed_hausdorff
    hd95 = []
    for i in range(3):  # Assuming 3 classes (background, cup, disc)
        pred_class = (pred == i).cpu().numpy()
        target_class = (target == i).cpu().numpy()
        try:
            # 计算Hausdorff距离，取95%分位数
            hd = directed_hausdorff(pred_class, target_class)[0]
            hd95.append(hd)
        except ValueError:
            hd95.append(np.nan)
    return hd95

class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

def load_config(config_filename):
    config_path = "configs.{}".format(config_filename.split('.')[0])
    module = importlib.import_module(config_path)
    return module.Config()

def splitprint():
    print("#" * 100)

def runid_checker(opts, if_syn=False):
    rootpath = opts.train_collection
    if if_syn:
        rootpath = opts.syn_collection
    valset_name = os.path.split(opts.val_collection)[-1]
    config_filename = opts.model_configs
    run_id = opts.run_id
    target_path = os.path.join(rootpath, "models", valset_name, config_filename, "run_" + str(run_id))
    if os.path.exists(target_path):
        if opts.overwrite:
            shutil.rmtree(target_path)
        else:
            print("'{}' exists!".format(target_path))
            return False
    os.makedirs(target_path)
    print("checkpoints are saved in '{}'".format(target_path))
    return True

def predict_dataloader(model, loader, device, net_name="mm-model", if_test=False):
    if type(model) is not list:
        model.eval()
    else:
        model[0].eval()
        model[1].eval()
    predicts, predicts_fine = [], []
    scores = []
    scores_fine = []
    expects, expects_fine = [], []

    eye_level_predict = defaultdict(list)
    eye_level_expect = defaultdict(list)

    for i, data in enumerate(loader):
            with torch.no_grad():
                # 根据 net_name 提取 inputs 和 labels
                if net_name == "cfp-model" or net_name == "oct-model":
                    inputs, labels_onehot, imagenames = data
                    outputs = model(inputs.to(device))
                elif net_name == "cfp-mt-model":
                    inputs, labels_onehot, mask, imagenames = data
                    _,outputs = model(inputs.to(device))  # 模型需要自行适配输入
                elif net_name == "cfp-oct-single-model":
                    inputs_cfp, inputs_oct, labels_onehot, imagenames = data
                    outputs = model(inputs_cfp.to(device), inputs_oct.to(device))
                elif net_name == "cfpmt-oct-model":
                    inputs_cfp, inputs_oct, labels_onehot,mask, imagenames = data
                    outputs_s,cfp_map = model[0](inputs_cfp.to(device))
                    outputs = model[1](inputs_oct.to(device),cfp_map)
                else:
                    raise ValueError(f"Unsupported loader mode: {net_name}")

                # 处理输出，假设使用 Softmax
                outputs = torch.nn.Softmax(dim=1)(outputs)
                eye_id = '-'.join(imagenames[0].split('-')[0:2])
                eye_level_predict[eye_id].extend(outputs.cpu().numpy().tolist())
                if eye_id not in eye_level_expect:
                    eye_level_expect[eye_id] = labels_onehot.cpu().numpy()

            scores_fine.extend(outputs.cpu().numpy().astype(np.int64).tolist())
            predict_fine = torch.round(outputs).cpu().numpy().astype(np.int64).tolist()
            predicts_fine.extend(predict_fine)
            expects_fine.extend(labels_onehot.cpu().numpy().tolist())

    for eye_id in eye_level_predict:
        predict = np.array([np.max(np.array(eye_level_predict[eye_id])[:, i]) for i in range(3)])
        scores.append(predict)
        predict = np.int64(torch.from_numpy(predict).squeeze(0).cpu().numpy() >= 0.5).tolist()
        predicts.append(predict)
        expects.extend(eye_level_expect[eye_id])
    return predicts, scores, expects, predicts_fine, scores_fine, expects_fine
