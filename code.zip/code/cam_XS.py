import os
import torch
import numpy as np
import cv2
from tqdm import tqdm
from models.geomm_net import geomm_net_MT,geomm_net_tmi2024_MT2,XS_MultiNet
import matplotlib.pyplot as plt

class HeatmapGenerator:
    def __init__(self, model, target_layer, device, task_index=0):
        """
        Args:
            task_index: 0表示第一个任务，1表示第二个任务
        """
        self.model = model
        self.target_layer = target_layer
        self.device = device
        self.task_index = task_index
        self.activations = None
        self.gradients = None
        
        # 注册钩子
        self._register_hooks()
    
    def _register_hooks(self):
        """注册前向和反向钩子"""
        def forward_hook(module, input, output):
            self.activations = output.detach().clone()
            
        def backward_hook(module, grad_input, grad_output):
            self.gradients = grad_output[0].detach().clone()
        
        self.target_layer.register_forward_hook(forward_hook)
        self.target_layer.register_backward_hook(backward_hook)
    
    def _safe_reduce(self, tensor, reduction_dims):
        """安全维度归约，防止索引越界"""
        valid_dims = [d for d in reduction_dims if d < tensor.dim()]
        if not valid_dims:
            return tensor
        return tensor.mean(dim=valid_dims, keepdim=True)
    
    def generate(self, input_tensor, target_class=None):
        """生成指定任务的热力图"""
        self.model.zero_grad()
        B, M, C, H, W = input_tensor.shape
        
        # 前向传播
        x = input_tensor.view(B*M, C, H, W)
        output1, output2 = self.model(x.unsqueeze(0))  # 保持与forward兼容
        
        # 自动确定目标类别
        if target_class is None:
            if self.task_index == 0:
                logits = output1
            else:
                logits = output2
            target_class = logits.argmax(dim=1).item()
        
        # 反向传播指定任务的梯度
        if self.task_index == 0:
            output = output1
        else:
            output = output2
        
        one_hot = torch.zeros_like(output)
        one_hot[0][target_class] = 1.0
        output.backward(gradient=one_hot, retain_graph=True)
        
        # 检查梯度激活
        if self.gradients is None or self.activations is None:
            raise RuntimeError("梯度或激活未捕获，请检查钩子注册")
        
        # 动态维度处理
        reduction_dims = list(range(2, self.gradients.dim()))
        weights = self._safe_reduce(self.gradients, reduction_dims)
        
        # 多视图热力图生成
        cams = []
        for i in range(M):
            view_act = self.activations[i::M]  # 按视图分离
            view_weights = weights[i::M]
            
            # 维度对齐计算
            if view_act.dim() == 4 and view_weights.dim() == 4:
                cam = (view_act * view_weights).sum(dim=1)
            elif view_act.dim() == 3 and view_weights.dim() == 3:
                cam = (view_act * view_weights.unsqueeze(-1)).sum(dim=1)
            else:
                raise ValueError(f"维度不匹配: act={view_act.shape}, weights={view_weights.shape}")
            
            # 后处理
            cam = torch.relu(cam)
            cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
            cams.append(cam.mean(0).cpu().numpy())
        
        return cams
    
def load_test_sample(npz_path, device):
    """完全复现XS_Dataset的测试模式加载逻辑"""
    data = np.load(npz_path)
    images = data['channel_concat_image']  # (9, 3, 44, 224)
    img = cv2.resize(images[0].transpose(1, 2, 0), (44, 224), interpolation=cv2.INTER_LINEAR)
    # 转换为Tensor并应用与训练时相同的归一化
    images = torch.from_numpy(images).float()
    images = (images - 0.5) / 0.5  # 对应Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))
    
    return images.unsqueeze(0).to(device)  # [1, 9, 3, 44, 224]

# def visualize_heatmaps(original_imgs, heatmaps, output_dir, case_id):
#     """可视化9张图像的热力图叠加效果"""
#     os.makedirs(output_dir, exist_ok=True)
    
#     # 创建3x3布局
#     fig, axes = plt.subplots(3, 3, figsize=(10, 3))
#     for idx in range(9):
#         ax = axes[idx//3, idx%3]
        
#         # 原始图像反归一化
#         img = original_imgs[idx].cpu().numpy().transpose(1, 2, 0)
#         img = (img * 0.5 + 0.5) * 255  # 恢复原始数值范围
        
        
#         # 调整热力图尺寸
#         h, w = img.shape[:2]
#         heatmap = cv2.resize(heatmaps[idx], (w, h))
#         heatmap = np.uint8(255 * heatmap)
#         heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
#         # 叠加显示
#         superimposed = cv2.addWeighted(img.astype(np.uint8), 0.7, 
#                                       heatmap, 0.8, 0)
#         ax.imshow(cv2.cvtColor(superimposed, cv2.COLOR_BGR2RGB))
#         ax.axis('off')
    
#     plt.suptitle(f'Case: {case_id}', fontsize=16)
#     plt.tight_layout()
#     plt.savefig(os.path.join(output_dir, f'{case_id}_heatmap.jpg'))
#     plt.close()

def visualize_heatmaps(original_imgs, heatmaps, output_dir, case_id):
    """可视化9张图像的热力图叠加效果和纯热力图"""
    # 为当前case创建专属文件夹
    case_dir = os.path.join(output_dir, str(case_id))
    os.makedirs(case_dir, exist_ok=True)
    
    # 创建3x3布局用于叠加热力图
    fig, axes = plt.subplots(3, 3, figsize=(10, 3))
    
    for idx in range(9):
        # 处理原始图像
        img = original_imgs[idx].cpu().numpy().transpose(1, 2, 0)
        img = (img * 0.5 + 0.5) * 255  # 恢复原始数值范围
        h, w = img.shape[:2]
        
        # 处理热力图
        cur_heatmap = heatmaps[idx]
        heatmap = cv2.resize(cur_heatmap, (w, h))
        heatmap = np.uint8(255 * heatmap)
        heatmap_colored = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
        heatmap_rgb = cv2.cvtColor(heatmap_colored, cv2.COLOR_BGR2RGB)  # 转换为RGB
        
        # ==== 生成并保存纯热力图 ====
        plt.figure()
        plt.imshow(heatmap_rgb)  # 使用RGB版本
        plt.axis('off')
        plt.savefig(os.path.join(case_dir, f'pure_heatmap_{idx}.jpg'), 
                   bbox_inches='tight', pad_inches=0)
        plt.close()
        # =========================
        
        # 创建叠加效果并添加到子图
        superimposed = cv2.addWeighted(img.astype(np.uint8), 0.7, 
                                      heatmap_colored, 0.8, 0)
        superimposed_rgb = cv2.cvtColor(superimposed, cv2.COLOR_BGR2RGB)  # 转换为RGB
        ax = axes[idx//3, idx%3]
        ax.imshow(superimposed_rgb)
        ax.axis('off')
    
    # 保存叠加热力图
    plt.suptitle(f'Case: {case_id}', fontsize=16)
    plt.tight_layout()
    plt.savefig(os.path.join(case_dir, f'{case_id}_heatmap.jpg'))
    plt.close()
    
def process_cases(npz_dir, output_root, model, device):
    """批量处理NPZ文件"""
    # 初始化热力图生成器
    target_layer = model.encoder_f.patch_embed4.proj  # 根据实际结构调整
    heatmap_gen = HeatmapGenerator(model, target_layer, device)
    
    # 获取所有NPZ文件
    npz_files = [f for f in os.listdir(npz_dir) if f.endswith('.npz')]
    
    for npz_file in tqdm(npz_files, desc='Generating heatmaps'):
        case_id = os.path.splitext(npz_file)[0]
        npz_path = os.path.join(npz_dir, npz_file)
        
        try:
            # 加载数据（完全复现测试集处理流程）
            input_tensor = load_test_sample(npz_path, device)
            
            # 生成热力图
            heatmaps = heatmap_gen.generate(input_tensor)
            
            # 可视化保存
            original_imgs = input_tensor.squeeze(0).cpu()  # [9, 3, 44, 224]
            visualize_heatmaps(original_imgs, heatmaps, output_root, case_id)
            
        except Exception as e:
            print(f"Error processing {case_id}: {str(e)}")
            continue

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 加载模型（保持与训练时完全一致的配置）
    model = XS_MultiNet().to(device)
    print(model)
    weights_path = "/disk/user/yt/nine_position/data_split/fold4/train/models/val/config_XS.py/run_4/best_3cls_model.pth"
    checkpoint = torch.load(weights_path, map_location=device)
    model.load_state_dict(checkpoint)
    model.eval()
    
    # 设置路径
    npz_dir = "/disk/user/yt/nine_position/data_split/fold4/val"  # 包含测试集NPZ文件的目录
    output_root = "/disk/user/yt/nine_position/data_split/fold4/hmap"
    
    # 执行处理
    process_cases(
        npz_dir=npz_dir,
        output_root=output_root,
        model=model,
        device=device
    )